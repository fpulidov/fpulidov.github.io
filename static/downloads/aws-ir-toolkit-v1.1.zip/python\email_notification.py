import boto3
import json
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    ses = boto3.client("ses")
    securityhub = boto3.client("securityhub")

    from_email = os.environ["SES_FROM_EMAIL"]
    to_email = os.environ["SES_TO_EMAIL"]

    findings = event["detail"]["findings"]

    for finding in findings:
        title = finding["Title"]
        severity = finding["Severity"]["Label"]
        resource_id = finding["Resources"][0]["Id"]
        resource_type = finding["Resources"][0]["Type"]
        account = finding["AwsAccountId"]
        region = finding["Region"]
        finding_id = finding["Id"]
        product_arn = finding["ProductArn"]
        description = finding.get("Description", "No description available.")

        subject = f"[AWS IR] {severity} — {title}"

        body = (
            f"A new Security Hub finding requires attention.\n\n"
            f"Title:         {title}\n"
            f"Severity:      {severity}\n"
            f"Account:       {account}\n"
            f"Region:        {region}\n"
            f"Resource Type: {resource_type}\n"
            f"Resource ID:   {resource_id}\n"
            f"Finding ID:    {finding_id}\n\n"
            f"Description:\n{description}\n\n"
            f"Review this finding in Security Hub:\n"
            f"https://{region}.console.aws.amazon.com/securityhub/home?region={region}#/findings"
        )

        ses.send_email(
            Source=from_email,
            Destination={"ToAddresses": [to_email]},
            Message={
                "Subject": {"Data": subject},
                "Body": {"Text": {"Data": body}},
            },
        )

        securityhub.batch_update_findings(
            FindingIdentifiers=[{"Id": finding_id, "ProductArn": product_arn}],
            Workflow={"Status": "NOTIFIED"},
        )

        logger.info(f"Notified: {title} ({severity}) in {account}/{region}")

    return {"statusCode": 200, "findingsProcessed": len(findings)}
