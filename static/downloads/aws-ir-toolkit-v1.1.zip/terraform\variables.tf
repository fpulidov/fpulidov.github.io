variable "aws_region" {
  description = "AWS region for deployment"
  type        = string
  default     = "eu-west-1"
}

variable "ses_from_email" {
  description = "Verified SES sender email address"
  type        = string
}

variable "ses_to_email" {
  description = "Email address to receive IR notifications"
  type        = string
}

variable "environment" {
  description = "Environment name (e.g. production, staging)"
  type        = string
  default     = "production"
}
