# AWS Incident Notification Flows

Three notification architectures for routing security findings to your team. The email flow (Flow 1) is fully implemented in the `terraform/` and `python/` directories. Flows 2 and 3 are reference architectures you can extend.

---

## Flow 1: Security Hub → EventBridge → Lambda → SES (Email)

**Included in this toolkit — deploy with `terraform apply`.**

### Trigger
- New Security Hub finding imported
- WorkflowStatus: `NEW`
- ComplianceStatus: `FAILED`
- Severity: `MEDIUM`, `HIGH`, or `CRITICAL`

### How It Works
1. EventBridge matches incoming Security Hub findings against the severity/compliance filter
2. EventBridge invokes the `ir-email-notification` Lambda function
3. Lambda extracts finding metadata (title, severity, account, region, resource)
4. Lambda sends a formatted email via SES
5. Lambda marks the finding as `NOTIFIED` in Security Hub to prevent duplicate alerts

### What You Need
- A verified SES sender email (or SES out of sandbox mode)
- The `ses_from_email` and `ses_to_email` variables set in `terraform.tfvars`

---

## Flow 2: GuardDuty / Security Hub → Lambda → Slack Webhook

**Lambda code included (`python/slack_notification.py`). Terraform for a second target is left as an exercise — add an `aws_cloudwatch_event_target` pointing to a second Lambda.**

### Trigger
- Same EventBridge rule as Flow 1 (or a separate rule for GuardDuty-only findings)

### How It Works
1. EventBridge invokes the Slack Lambda function
2. Lambda formats the finding as a Slack Block Kit message with severity color-coding
3. Lambda posts to a Slack webhook URL (configured via environment variable)
4. The message includes a direct link to Security Hub for the finding

### Slack Message Includes
- Severity level with color indicator (red/orange/yellow/green)
- Finding title and source service
- Account ID and region
- Resource type and ID
- Description (truncated to 500 chars)
- "View in Security Hub" button

### What You Need
- A Slack incoming webhook URL (create one at https://api.slack.com/messaging/webhooks)
- A second Lambda function deployed with the `SLACK_WEBHOOK_URL` environment variable

---

## Flow 3: IAM Policy Changes → CloudTrail → EventBridge → SQS Queue

**Reference architecture — no code included.**

### Trigger
CloudTrail detects IAM privilege-related API calls:
- `PutUserPolicy`, `AttachUserPolicy`, `AttachRolePolicy`
- `CreatePolicyVersion`, `PutRolePolicy`
- `CreateAccessKey`, `CreateLoginProfile`

### How It Works
1. CloudTrail logs IAM API calls to the management event trail
2. EventBridge rule matches specific IAM write actions
3. Matching events are sent to an SQS queue for the security team
4. A consumer (Lambda, Step Functions, or manual review) processes the queue

### EventBridge Rule Pattern (Example)
```json
{
  "source": ["aws.iam"],
  "detail-type": ["AWS API Call via CloudTrail"],
  "detail": {
    "eventSource": ["iam.amazonaws.com"],
    "eventName": [
      "AttachUserPolicy",
      "AttachRolePolicy",
      "PutUserPolicy",
      "PutRolePolicy",
      "CreatePolicyVersion",
      "CreateAccessKey"
    ]
  }
}
```

### Optional Enhancements
- Chain SNS topics to fan out to both email and Slack simultaneously
- Add Lambda enrichment before queuing (lookup the IAM principal, tag the resource)
- Integrate with AWS Chatbot for direct Slack/Teams visibility
- Use Step Functions to orchestrate multi-step response (alert → confirm → remediate)
