data "archive_file" "email_notification" {
  type        = "zip"
  output_path = "${path.module}/../python/email_notification.zip"
  source_file = "${path.module}/../python/email_notification.py"
}

resource "aws_lambda_function" "ir_notifier" {
  filename         = data.archive_file.email_notification.output_path
  function_name    = "ir-email-notification"
  role             = aws_iam_role.lambda_ir_notifier.arn
  handler          = "email_notification.lambda_handler"
  source_code_hash = data.archive_file.email_notification.output_base64sha256
  runtime          = "python3.12"
  timeout          = 30

  environment {
    variables = {
      SES_FROM_EMAIL = var.ses_from_email
      SES_TO_EMAIL   = var.ses_to_email
    }
  }
}
