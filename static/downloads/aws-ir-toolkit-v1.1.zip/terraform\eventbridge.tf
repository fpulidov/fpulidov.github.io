resource "aws_cloudwatch_event_rule" "securityhub_new_finding" {
  name        = "securityhub-ir-notification"
  description = "Trigger on new Security Hub findings with FAILED compliance and severity >= MEDIUM"

  event_pattern = jsonencode({
    source      = ["aws.securityhub"]
    detail-type = ["Security Hub Findings - Imported"]
    detail = {
      findings = {
        Workflow     = { Status = ["NEW"] }
        Compliance   = { Status = ["FAILED"] }
        Severity     = { Label = ["MEDIUM", "HIGH", "CRITICAL"] }
      }
    }
  })
}

resource "aws_cloudwatch_event_target" "send_to_lambda" {
  rule      = aws_cloudwatch_event_rule.securityhub_new_finding.name
  target_id = "ir-email-notification"
  arn       = aws_lambda_function.ir_notifier.arn
}

resource "aws_lambda_permission" "allow_eventbridge" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ir_notifier.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.securityhub_new_finding.arn
}
