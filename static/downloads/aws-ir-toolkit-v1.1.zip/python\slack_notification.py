import json
import os
import logging
from urllib.request import Request, urlopen
from urllib.error import URLError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SLACK_WEBHOOK_URL = os.environ["SLACK_WEBHOOK_URL"]

SEVERITY_COLORS = {
    "CRITICAL": "#FF0000",
    "HIGH": "#FF6600",
    "MEDIUM": "#FFAA00",
    "LOW": "#00AA00",
    "INFORMATIONAL": "#0088CC",
}


def lambda_handler(event, context):
    findings = event["detail"]["findings"]

    for finding in findings:
        title = finding["Title"]
        severity = finding["Severity"]["Label"]
        resource_id = finding["Resources"][0]["Id"]
        resource_type = finding["Resources"][0]["Type"]
        account = finding["AwsAccountId"]
        region = finding["Region"]
        description = finding.get("Description", "No description available.")
        source = finding.get("ProductFields", {}).get("aws/securityhub/ProductName", "Security Hub")
        color = SEVERITY_COLORS.get(severity, "#CCCCCC")

        slack_message = {
            "attachments": [
                {
                    "color": color,
                    "blocks": [
                        {
                            "type": "header",
                            "text": {
                                "type": "plain_text",
                                "text": f"AWS IR Alert — {severity}",
                            },
                        },
                        {
                            "type": "section",
                            "fields": [
                                {"type": "mrkdwn", "text": f"*Title:*\n{title}"},
                                {"type": "mrkdwn", "text": f"*Source:*\n{source}"},
                                {"type": "mrkdwn", "text": f"*Account:*\n{account}"},
                                {"type": "mrkdwn", "text": f"*Region:*\n{region}"},
                                {"type": "mrkdwn", "text": f"*Resource:*\n{resource_type}"},
                                {"type": "mrkdwn", "text": f"*Resource ID:*\n{resource_id}"},
                            ],
                        },
                        {
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": f"*Description:*\n{description[:500]}",
                            },
                        },
                        {
                            "type": "actions",
                            "elements": [
                                {
                                    "type": "button",
                                    "text": {"type": "plain_text", "text": "View in Security Hub"},
                                    "url": f"https://{region}.console.aws.amazon.com/securityhub/home?region={region}#/findings",
                                }
                            ],
                        },
                    ],
                }
            ]
        }

        payload = json.dumps(slack_message).encode("utf-8")
        req = Request(SLACK_WEBHOOK_URL, data=payload, headers={"Content-Type": "application/json"})

        try:
            response = urlopen(req)
            logger.info(f"Slack notified: {title} ({severity}) — status {response.getcode()}")
        except URLError as e:
            logger.error(f"Failed to send to Slack: {e}")
            raise

    return {"statusCode": 200, "findingsProcessed": len(findings)}
