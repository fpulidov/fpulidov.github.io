# AWS Incident Response Toolkit v1.1

This toolkit helps cloud security teams respond faster, stay compliant, and document their process during incidents in AWS environments.

---

## What's Included

| File | Description |
|------|-------------|
| `Incident response playbook template.pdf` | Printable IR playbook aligned to ISO 27001 and AWS workflows |
| `Notification_Flows_Extended.md` | Three notification flow architectures (SES email, Slack, SQS queue) |
| `Cloud_Forensics_Tool_Matrix.xlsx` | Cloud-native and open-source forensic tools by category |
| `terraform/` | Terraform code to deploy the EventBridge → Lambda → SES notification pipeline |
| `python/email_notification.py` | Lambda function — sends SES email on new Security Hub findings |
| `python/slack_notification.py` | Lambda function — sends Slack alerts on new Security Hub findings |

---

## Quick Start

### 1. Configure Variables

Create a `terraform.tfvars` file in the `terraform/` directory:

```hcl
aws_region     = "eu-west-1"
ses_from_email = "alerts@yourdomain.com"
ses_to_email   = "security-team@yourdomain.com"
```

**Prerequisites:**
- The sender email must be verified in SES (or your SES account must be out of sandbox mode)
- AWS credentials configured locally (`aws configure` or environment variables)

### 2. Deploy

```bash
cd terraform
terraform init
terraform plan    # review what will be created
terraform apply
```

This creates:
- An EventBridge rule matching Security Hub findings (severity >= MEDIUM, compliance FAILED)
- A Lambda function that sends email notifications via SES
- IAM role with least-privilege permissions (SES send + Security Hub update)
- CloudWatch log group for Lambda logs

### 3. Test

Generate sample findings in Security Hub to verify the pipeline:

```bash
aws securityhub create-sample-findings --region eu-west-1
```

### 4. Slack Notifications (Optional)

The `python/slack_notification.py` Lambda function sends formatted alerts to a Slack channel via webhook. To deploy it:

1. Create a Slack webhook URL in your workspace
2. Create a second Lambda function using the same IAM role
3. Add the `SLACK_WEBHOOK_URL` environment variable
4. Add a second EventBridge target pointing to the Slack Lambda

The Slack function uses only `urllib` (built into Python) — no external dependencies required.

---

## Customization

- **Severity filter:** Edit `eventbridge.tf` to change which severity levels trigger notifications. The default is MEDIUM, HIGH, and CRITICAL.
- **Email format:** Edit `email_notification.py` to customize the email body and subject line.
- **Remote state:** Replace the local backend in `providers.tf` with S3 for team environments.

---

## Support

Questions or feedback: javier@thehiddenport.dev

For more AWS security guides: [https://thehiddenport.dev](https://thehiddenport.dev)
